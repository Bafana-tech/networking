from socket import *
import select
import sys

serverName = '127.0.0.1'
serverPort = 12000
clientSocket = socket(AF_INET, SOCK_DGRAM)

# a login message has the form login 'username'
login = input("Enter username: ")
clientSocket.sendto(login.encode(), (serverName, serverPort))
modifiedMessage, serverAddress = clientSocket.recvfrom(2048)
print(modifiedMessage.decode())

while True:
    input_type = [sys.stdin, clientSocket]
    r, w, e = select.select(input_type, [], [])

    for sock in r:
        if sock == clientSocket:
            text = sock.recv(2048)
            print(text)
        else:
            text = sys.stdin.readline()
            clientSocket.sendto(text.encode(), (serverName, serverPort))
    #message = input("Input message:")
    #if message == "exit":
     #   clientSocket.close()
    #clientSocket.sendto(message.encode(), (serverName, serverPort))
    #modifiedMessage, serverAddress = clientSocket.recvfrom(2048)
    #print(modifiedMessage.decode())

clientSocket.close()