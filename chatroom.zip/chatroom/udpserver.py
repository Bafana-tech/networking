from socket import *


serverPort = 12000
serverSocket = socket(AF_INET, SOCK_DGRAM)
serverSocket.bind(('127.0.0.1', serverPort))
print("The server is ready to receive")

clients = []
ipList = []

while True:
    message, clientAddress = serverSocket.recvfrom(2048)
    msg = message.decode()
    #client login
    if msg[:5] == "login":
        if msg[6:] in clients:
            well = "Welcome back"
            serverSocket.sendto(well.encode(), clientAddress)
        else:
            clients.append(msg[6:])
            ipList.append(clientAddress)
            welcome = "You are in the chatroom!"
            serverSocket.sendto(welcome.encode(), clientAddress)
            print(ipList)


    elif msg[:4] == "CHAT":
        if msg[6:msg.index(">")] in clients:
            # details of the reciever
            #print("<"+clientAddress+"> "+msg)
            name = msg[msg.index("<")+1:msg.index(">")]
            index = clients.index(name)
            addr = ipList[index]
            serverSocket.sendto(msg[msg.index(">")+2:].encode(), addr)
            print("message sent")

        else:
            text = "Sorry. Your receiver <"+name+"> is not in the chatroom"
            serverSocket.sendto(text.encode(), clientAddress)


    elif msg == "Exit" or msg=="exit":
        exit = "Disconnected"
        serverSocket.sendto(exit.encode(), clientAddress)

    else:
        text2 = "Invalid command"
        serverSocket.sendto(text2.encode(), clientAddress)

